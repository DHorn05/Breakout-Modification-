using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;

namespace BreakoutTest
{
    interface IBallLauncher
    {
        void Launch(GameTime gameTime);
    }

    class BallManager : DrawableGameComponent, IBallLauncher
    {
        readonly IScoreManager scoreManager;
        readonly List<Ball> balls;

        public Ball PrimaryBall { get; private set; }
        public event System.Action<Ball> BallAdded;
        public event System.Action<Ball> BallRemoved;

        public BallManager(Game game, IScoreManager scoreManager)
            : base(game)
        {
            this.scoreManager = scoreManager;
            balls = new List<Ball>();
            PrimaryBall = new Ball(game, scoreManager);
            balls.Add(PrimaryBall);
        }

        public override void Initialize()
        {
            PrimaryBall.Initialize();
            PrimaryBall.Load();
            NotifyBallAdded(PrimaryBall);
            base.Initialize();
        }

        public Ball AddBall(Vector2 location)
        {
            Ball ball = new Ball(Game, scoreManager);
            ball.Initialize();
            ball.Load();
            ball.SpawnAt(location, new Vector2(0.75f, -1));
            balls.Add(ball);
            NotifyBallAdded(ball);
            return ball;
        }

        public void Launch(GameTime gameTime)
        {
            PrimaryBall.LaunchBall(gameTime);
        }

        public void SetLevel(int level)
        {
            foreach (Ball ball in balls)
                ball.SetLevel(level);
        }

        private void NotifyBallAdded(Ball ball)
        {
            if (BallAdded != null)
                BallAdded(ball);
        }

        private void NotifyBallRemoved(Ball ball)
        {
            if (BallRemoved != null)
                BallRemoved(ball);
        }

        public override void Update(GameTime gameTime)
        {
            foreach (Ball ball in balls)
                ball.Update(gameTime);

            if (balls.All(ball => ball.State == BallState.GameOver) && scoreManager.Lives > 0)
            {
                scoreManager.LoseLife();
                foreach (Ball ball in balls.Where(ball => ball != PrimaryBall).ToArray())
                {
                    balls.Remove(ball);
                    NotifyBallRemoved(ball);
                }
                PrimaryBall.PrepareForServe();
            }

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            foreach (Ball ball in balls)
            {
                if (ball.State != BallState.GameOver)
                    ball.Draw(gameTime);
            }

            base.Draw(gameTime);
        }
    }
}
