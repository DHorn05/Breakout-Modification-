﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonoGameLibrary.Sprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary.Util;


namespace BreakoutTest
{
    enum BallState { OnPaddleStart, Playing, GameOver }

    class Ball : DrawableSprite
    {
        
        public BallState State { get; private set; }

        GameConsole console;
        readonly IScoreManager scoreManager;
        Vector2 previousLocation;
        const float BaseSpeed = 190f;

        public Ball(Game game, IScoreManager scoreManager)
            : base(game)
        {
            this.scoreManager = scoreManager;
            this.State = BallState.OnPaddleStart;

            console = (GameConsole)this.Game.Services.GetService(typeof(IGameConsole));
            if (console == null) //ohh no no console
            {
                console = new GameConsole(this.Game);
                this.Game.Components.Add(console);  //add a new game console to Game
            }
            // this.ShowMarkers = true;
        }

        internal void Load()
        {
            this.LoadContent();
        }

        public void SetInitialLocation()
        {
            this.Location = new Vector2(200, 300);
        }

        public void LaunchBall(GameTime gameTime)
        {
            if (scoreManager.Lives <= 0)
                return;

            this.Direction = Vector2.Normalize(new Vector2(1, -1));
            this.Speed = BaseSpeed + (scoreManager.Level - 1) * 15;
            this.State =  BallState.Playing;
            this.console.GameConsoleWrite("Ball Launched " + gameTime.TotalGameTime.ToString());
        }

        public void SetLevel(int level)
        {
            if (this.State == BallState.Playing)
                this.Speed = BaseSpeed + (level - 1) * 15;
        }

        public void SpawnAt(Vector2 location, Vector2 direction)
        {
            this.Location = location;
            this.Direction = Vector2.Normalize(direction);
            this.Speed = BaseSpeed + (scoreManager.Level - 1) * 15;
            this.State = BallState.Playing;
        }

        public void PrepareForServe()
        {
            this.Speed = 0;
            this.Direction = Vector2.Zero;
            this.State = scoreManager.Lives > 0 ? BallState.OnPaddleStart : BallState.GameOver;
        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("ballSmall");
            SetInitialLocation();
            base.LoadContent();
        }

        private void resetBall(GameTime gameTime)
        {
            this.Speed = 0;
            this.State = BallState.GameOver;
            this.console.GameConsoleWrite("Ball Reset " + gameTime.TotalGameTime.ToString());
        }

        public override void Update(GameTime gameTime)
        {
            switch(this.State)
            {
                case BallState.OnPaddleStart:
                    break;

                case BallState.Playing:
                    UpdateBall(gameTime);
                    break;

                case BallState.GameOver:
                    break;
            }
            
            base.Update(gameTime);
        }

        private void UpdateBall(GameTime gameTime)
        {
            previousLocation = this.Location;
            this.Location += this.Direction * (this.Speed * (float)gameTime.ElapsedGameTime.TotalSeconds);

            float rightEdge = this.Game.GraphicsDevice.Viewport.Width - this.spriteTexture.Width;
            if (this.Location.X > rightEdge)
            {
                this.Location.X = rightEdge;
                this.Direction.X = -Math.Abs(this.Direction.X);
            }
            else if (this.Location.X < 0)
            {
                this.Location.X = 0;
                this.Direction.X = Math.Abs(this.Direction.X);
            }

            if (this.Location.Y < 0)
            {
                this.Location.Y = 0;
                this.Direction.Y = Math.Abs(this.Direction.Y);
            }

            if (this.Location.Y + this.spriteTexture.Height >= this.Game.GraphicsDevice.Viewport.Height)
            {
                this.resetBall(gameTime);
            }
        }

        public void Reflect(Block block)
        {
            Rectangle previousBall = new Rectangle(
                (int)previousLocation.X,
                (int)previousLocation.Y,
                this.spriteTexture.Width,
                this.spriteTexture.Height);

            if (previousBall.Bottom <= block.LocationRect.Top ||
                previousBall.Top >= block.LocationRect.Bottom)
                this.Direction.Y *= -1;
            else
                this.Direction.X *= -1;
        }

        public void BounceOffPaddle(float hitOffset, float paddleMovement)
        {
            float angle = MathHelper.Clamp(
                hitOffset * MathHelper.ToRadians(60) +
                paddleMovement * MathHelper.ToRadians(15),
                -MathHelper.ToRadians(70),
                MathHelper.ToRadians(70));

            this.Direction = new Vector2((float)Math.Sin(angle), -(float)Math.Cos(angle));
        }

    }
}
