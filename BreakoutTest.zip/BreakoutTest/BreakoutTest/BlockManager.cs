﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BreakoutTest
{
    class BlockManager : DrawableGameComponent
    {

        public List<Block> Blocks { get; private set; } //List of Blocks the are managed by Block Manager

        readonly List<Ball> balls;
        readonly IScoreManager scoreManager;

        List<Block> blocksToRemove; //list of block to remove probably because they were hit
        Dictionary<Ball, HashSet<Block>> blocksCurrentlyTouching;
        readonly Random random;
        bool hasLoadedLevel;
        public event Action<Vector2> BonusBallRequested;

        /// <summary>
        /// BlockManager hold a list of blocks and handles updating, drawing a block collision
        /// </summary>
        /// <param name="game">Reference to Game</param>
        /// <param name="ball">Refernce to Ball for collision</param>
        public BlockManager(Game game, IScoreManager scoreManager)
            : base(game)
        {
            this.Blocks = new List<Block>();
            this.balls = new List<Ball>();
            this.blocksToRemove = new List<Block>();
            this.blocksCurrentlyTouching = new Dictionary<Ball, HashSet<Block>>();
            this.random = new Random();
            
            this.scoreManager = scoreManager;
        }

        public void RegisterBall(Ball ball)
        {
            if (!balls.Contains(ball))
                balls.Add(ball);
        }

        public void UnregisterBall(Ball ball)
        {
            balls.Remove(ball);
            blocksCurrentlyTouching.Remove(ball);
        }

        public override void Initialize()
        {
            LoadLevel();
            base.Initialize();
        }

        /// <summary>
        /// Replacable Method to Load a Level by filling the Blocks List with Blocks
        /// </summary>
        protected virtual void LoadLevel()
        {
            if (hasLoadedLevel)
            {
                scoreManager.CompleteLevel();
            }

            int height = Math.Min(2 + (scoreManager.Level - 1) / 2, 5);
            CreateBlockArrayByWidthAndHeight(24, height, 1);
            hasLoadedLevel = true;
        }

        /// <summary>
        /// Simple Level lays out multiple levels of blocks
        /// </summary>
        /// <param name="width">Number of blocks wide</param>
        /// <param name="height">Number of blocks high</param>
        /// <param name="margin">space between blocks</param>
        private void CreateBlockArrayByWidthAndHeight(int width, int height, int margin)
        {
            Block b;
            int remainingSlots = width * height;
            int yellowBlocksRemaining = Math.Min(3, remainingSlots);
            for (int w = 0; w < width; w++)
            {
                for (int h = 0; h < height; h++)
                {
                    bool yellow = random.Next(remainingSlots) < yellowBlocksRemaining;
                    remainingSlots--;
                    if (yellow)
                        yellowBlocksRemaining--;

                    int hitPoints = yellow ? 1 : GetBlockHitPoints();
                    b = new Block(this.Game, hitPoints, yellow);
                    b.Initialize();
                    b.Load();
                    b.Location = new Vector2(5 + (w * b.SpriteTexture.Width + (w * margin)), 50 + (h * b.SpriteTexture.Height + (h * margin)));
                    Blocks.Add(b);
                }
            }
        }

        private int GetBlockHitPoints()
        {
            if (scoreManager.Level == 2 && random.Next(3) == 0)
                return 2;

            if (scoreManager.Level == 3 && random.Next(3) == 0)
                return random.Next(2, 4);

            return 1 + (scoreManager.Level - 1) / 3;
        }

        public override void Update(GameTime gameTime)
        {
            foreach (Block block in Blocks)
            {
                if (block.Enabled)
                    block.Update(gameTime);
            }

            UpdateCheckBlocksForCollision(gameTime);
            UpdateRemoveDisabledBlocks();

            if (hasLoadedLevel && Blocks.Count == 0)
                LoadLevel();

            base.Update(gameTime);
        }

        /// <summary>
        /// Removes disabled blocks from list
        /// </summary>
        private void UpdateRemoveDisabledBlocks()
        {
            //remove disabled blocks
            foreach (var block in blocksToRemove)
            {
                if (Blocks.Remove(block))
                {
                    scoreManager.AddScore(10);
                    if (block.IsYellow)
                    {
                        Vector2 spawnLocation = block.Location +
                            new Vector2(block.SpriteTexture.Width / 2f, block.SpriteTexture.Height);
                        if (BonusBallRequested != null)
                            BonusBallRequested(spawnLocation);
                    }
                }
            }
            foreach (Ball ball in blocksCurrentlyTouching.Keys.ToList())
            {
                if (!balls.Contains(ball))
                    blocksCurrentlyTouching.Remove(ball);
            }
            blocksToRemove.Clear();
        }

        private void UpdateCheckBlocksForCollision(GameTime gameTime)
        {
            foreach (Ball ball in balls)
            {
                if (ball.State != BallState.Playing)
                    continue;

                if (!blocksCurrentlyTouching.ContainsKey(ball))
                    blocksCurrentlyTouching.Add(ball, new HashSet<Block>());

                bool ballReflected = false;
                HashSet<Block> touchingBlocks = blocksCurrentlyTouching[ball];
                foreach (Block b in Blocks)
                {
                    if (!b.Enabled)
                        continue;

                    if (!b.Intersects(ball))
                    {
                        touchingBlocks.Remove(b);
                        continue;
                    }

                    if (touchingBlocks.Add(b))
                    {
                        if (b.HitByBall(ball) && !blocksToRemove.Contains(b))
                            blocksToRemove.Add(b);
                        if (!ballReflected)
                        {
                            ball.Reflect(b);
                            ballReflected = true;
                        }
                    }
                }
            }
        }



        public override void Draw(GameTime gameTime)
        {
            foreach (var block in this.Blocks)
            {
                block.Draw(gameTime);
            }
            base.Draw(gameTime);
        }
    }
}
