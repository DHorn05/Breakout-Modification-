﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonoGameLibrary.Sprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary.Util;

namespace BreakoutTest
{
    class Paddle : DrawableSprite
    {
        //Service Dependencies
        GameConsole console;

        //Dependencies
        PaddleController controller;
        readonly List<Ball> balls;
        
        public Paddle(Game game, IBallLauncher ballLauncher)
            : base(game)
        {
            this.Speed = 400;
            balls = new List<Ball>();
            controller = new PaddleController(game, ballLauncher);

            console = (GameConsole)this.Game.Services.GetService(typeof(IGameConsole));
            if (console == null) //ohh no no console
            {
                console = new GameConsole(this.Game);
                this.Game.Components.Add(console);  //add a new game console to Game
            }

        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("paddleSmall");
            // this.ShowMarkers = true;
            SetInitialLocation();
            base.LoadContent();
        }

        public void SetInitialLocation()
        {
            this.Location = new Vector2(300, 450);

        }

        public void RegisterBall(Ball ball)
        {
            if (!balls.Contains(ball))
                balls.Add(ball);
        }

        public void UnregisterBall(Ball ball)
        {
            balls.Remove(ball);
        }

        public void SetLevel(int level)
        {
            if (this.spriteTexture == null)
                return;

            float center = this.Location.X + this.spriteTexture.Width / 2f;
            string textureName = level % 2 == 0 ? "paddleBig" : "paddleSmall";
            this.SpriteTexture = this.Game.Content.Load<Texture2D>(textureName);
            this.Location.X = center - this.spriteTexture.Width / 2f;
            KeepPaddleOnScreen();
        }

        Rectangle collisionRectangle;  //Rectangle for paddle collision uses just the top of the paddle

        public override void Update(GameTime gameTime)
        {
            controller.HandleInput(gameTime);
            this.Direction = controller.Direction;
            this.Location += this.Direction * (this.Speed * (float)gameTime.ElapsedGameTime.TotalSeconds);
            KeepPaddleOnScreen();

            collisionRectangle = new Rectangle(
                (int)this.Location.X,
                (int)this.Location.Y,
                this.spriteTexture.Width,
                1);

            foreach (Ball ball in balls)
            {
                if (ball.State == BallState.OnPaddleStart)
                    UpdateMoveBallWithPaddle(ball);
                else if (ball.State == BallState.Playing)
                    UpdateCheckBallCollision(ball);
            }
            base.Update(gameTime);
        }

        private void UpdateMoveBallWithPaddle(Ball ball)
        {
            ball.Speed = 0;
            ball.Direction = Vector2.Zero;
            ball.Location = new Vector2(this.Location.X + (this.spriteTexture.Width / 2 - ball.SpriteTexture.Width / 2), this.Location.Y - ball.SpriteTexture.Height);
        }

        private void UpdateCheckBallCollision(Ball ball)
        {
            if (ball.Direction.Y > 0 &&
                collisionRectangle.Intersects(ball.LocationRect))
            {
                float paddleCenter = this.Location.X + this.spriteTexture.Width / 2f;
                float ballCenter = ball.Location.X + ball.SpriteTexture.Width / 2f;
                float hitOffset = (ballCenter - paddleCenter) / (this.spriteTexture.Width / 2f);
                hitOffset = MathHelper.Clamp(hitOffset, -1, 1);
                ball.Location.Y = this.Location.Y - ball.SpriteTexture.Height;
                ball.BounceOffPaddle(hitOffset, this.Direction.X);
                // console.GameConsoleWrite("Paddle collision ballLoc:" + ball.Location + " paddleLoc:" + this.Location.ToString());
            }
        }

        private void KeepPaddleOnScreen()
        {
            this.Location.X = MathHelper.Clamp(this.Location.X, 0, this.Game.GraphicsDevice.Viewport.Width - this.spriteTexture.Width);
        }
    }
}
