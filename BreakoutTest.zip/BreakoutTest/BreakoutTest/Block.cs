using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonoGameLibrary.Sprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BreakoutTest
{
    enum BlockState { Normal, Broken };

    class Block : DrawableSprite
    {
        protected BlockState _state;            
        public int HitPoints { get; private set; }
        public int MaxHitPoints { get; private set; }
        public bool IsYellow { get { return yellow; } }
        readonly bool yellow;

        public BlockState State
        {
            get { return _state; }
            protected set
            {
                if (this._state != value)       //Change state if it is different than previous state                
                {
                    this._state = value;
                }
            }
        }

        public Block(Game game, int hitPoints = 1, bool yellow = false)
            : base(game)
        {
            this.HitPoints = Math.Max(1, hitPoints);
            this.MaxHitPoints = this.HitPoints;
            this.yellow = yellow;
        }

        internal void Load()
        {
            this.LoadContent();
        }

        protected override void LoadContent()
        {
            string textureName = yellow
                ? "block_yellow"
                : MaxHitPoints == 1
                    ? "block_greenWaveSmall"
                    : MaxHitPoints == 2 ? "block_blue" : "block_red";
            this.spriteTexture = this.Game.Content.Load<Texture2D>(textureName);
            base.LoadContent();
        }

        /// <summary>
        /// Checks if ball is hit by block
        /// </summary>
        /// <param name="ball"></param>
        internal bool HitByBall(Ball ball)
        {
            if (this.State == BlockState.Broken)
                return false;

            this.HitPoints--;
            if (this.HitPoints <= 0)
            {
                this.Enabled = false;
                this.Visible = false;
                this.State = BlockState.Broken;
                return true;
            }

            return false;
        }
    }
}
