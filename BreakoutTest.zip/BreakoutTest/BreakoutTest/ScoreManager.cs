﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonoGameLibrary.Sprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary.Util;


namespace BreakoutTest
{
    interface IScoreManager
    {
        int Lives { get; }
        int Level { get; }
        event Action<int> LevelChanged;
        void AddScore(int points);
        void LoseLife();
        void CompleteLevel();
        void ShowStatus(string message, float seconds);
    }

    class ScoreManager : DrawableGameComponent, IScoreManager
    {

        SpriteFont font;
        public int Lives { get; private set; }
        public int Level { get; private set; }
        public int Score { get; private set; }
        public event Action<int> LevelChanged;

        Texture2D paddle;

        SpriteBatch sb;
        Vector2 scoreLoc, livesLoc, levelLoc;
        string statusMessage;
        float statusMessageTime;
        
        public ScoreManager(Game game)
            : base(game)
        {
            SetupNewGame();
        }

        private void SetupNewGame()
        {
            Lives = 3;
            Level = 1;
            Score = 0;
            statusMessage = null;
            statusMessageTime = 0;
        }

        public void AddScore(int points)
        {
            Score += points;
        }

        public void LoseLife()
        {
            Lives = Math.Max(0, Lives - 1);
            ShowStatus(Lives == 0 ? "Game Over" : "Ball lost", 2);
        }

        public void CompleteLevel()
        {
            Level++;
            ShowStatus("Level " + Level, 2);
            if (LevelChanged != null)
                LevelChanged(Level);
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(this.Game.GraphicsDevice);
            font = this.Game.Content.Load<SpriteFont>("Arial");
            paddle = this.Game.Content.Load<Texture2D>("paddleSmall");
            livesLoc = new Vector2(10, 10);
            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            if (statusMessageTime > 0)
                statusMessageTime = Math.Max(0, statusMessageTime - (float)gameTime.ElapsedGameTime.TotalSeconds);

            base.Update(gameTime);
        }

        public void ShowStatus(string message, float seconds)
        {
            statusMessage = message;
            statusMessageTime = seconds;
        }

        public override void Draw(GameTime gameTime)
        {
            string levelText = "Level: " + Level;
            string scoreText = "Score: " + Score;
            float screenWidth = this.Game.GraphicsDevice.Viewport.Width;
            levelLoc = new Vector2(
                (screenWidth - font.MeasureString(levelText).X) / 2,
                10);
            scoreLoc = new Vector2(
                screenWidth - font.MeasureString(scoreText).X - 10,
                10);

            sb.Begin();
            for (int i = 0; i < Lives; i++)
            {
                sb.Draw(paddle, new Rectangle((65 * i) + 100, 15, paddle.Width / 2, paddle.Height / 2), Color.White);
            }
            sb.DrawString(font, "Lives: " + Lives, livesLoc, Color.White);
            sb.DrawString(font, scoreText, scoreLoc, Color.White);
            sb.DrawString(font, levelText, levelLoc, Color.White);
            if (statusMessageTime > 0)
                sb.DrawString(font, statusMessage, new Vector2(300, 240), Color.White);
            else if (Lives == 0)
                sb.DrawString(font, "Game Over", new Vector2(300, 240), Color.White);
            sb.End();
            base.Draw(gameTime);
        }
    }
}
